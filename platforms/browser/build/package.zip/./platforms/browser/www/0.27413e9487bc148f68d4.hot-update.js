webpackHotUpdate(0,{

/***/ 633:
/* unknown exports provided */
/* all exports used */
/*!**************************!*\
  !*** ./src/utils/api.js ***!
  \**************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n            value: true\n});\nexports.getApiUrlFromConfig = undefined;\n\nvar _axios = __webpack_require__(!(function webpackMissingModule() { var e = new Error(\"Cannot find module \\\"axios\\\"\"); e.code = 'MODULE_NOT_FOUND'; throw e; }()));\n\nvar _axios2 = _interopRequireDefault(_axios);\n\nvar _config = __webpack_require__(/*! ./config */ 634);\n\nvar _config2 = _interopRequireDefault(_config);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar getApiUrlFromConfig = exports.getApiUrlFromConfig = function getApiUrlFromConfig() {\n            return \"http://karmajobs.servehttp.com/api\";\n};\nvar api = _axios2.default.create({\n            baseURL: _config2.default.get(\"api_url\", getApiUrlFromConfig()),\n            timeout: _config2.default.get(\"api_timeout\", 100000),\n            contentType: \"application/json\",\n            headers: { 'Authorization': \"Bearer \" + _config2.default.get(\"access_token\") }\n});\nexports.default = api;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjMzLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy91dGlscy9hcGkuanM/OTNhZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXHJcbmltcG9ydCBjb25maWcgZnJvbSAnLi9jb25maWcnXHJcbmV4cG9ydCBjb25zdCBnZXRBcGlVcmxGcm9tQ29uZmlnID0gKCkgPT4gKFwiaHR0cDovL2thcm1ham9icy5zZXJ2ZWh0dHAuY29tL2FwaVwiKVxyXG5jb25zdCBhcGkgPSBheGlvcy5jcmVhdGUoe1xyXG4gICAgICAgICAgICBiYXNlVVJMOiBjb25maWcuZ2V0KFwiYXBpX3VybFwiLCBnZXRBcGlVcmxGcm9tQ29uZmlnKCkpLFxyXG4gICAgICAgICAgICB0aW1lb3V0OiBjb25maWcuZ2V0KFwiYXBpX3RpbWVvdXRcIiwxMDAwMDApLFxyXG4gICAgICAgICAgICBjb250ZW50VHlwZTpcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgaGVhZGVyczogeydBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIrY29uZmlnLmdldChcImFjY2Vzc190b2tlblwiKX1cclxuICAgICAgICB9KTtcclxuZXhwb3J0IGRlZmF1bHQgYXBpO1xyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL3V0aWxzL2FwaS5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7OztBQUFBO0FBQ0E7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUEiLCJzb3VyY2VSb290IjoiIn0=");

/***/ }),

/***/ 634:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/utils/config.js ***!
  \*****************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/utils/config.js: Unexpected token (6:11)\\n\\n\\u001b[0m \\u001b[90m 4 | \\u001b[39m    \\u001b[36mthis\\u001b[39m\\u001b[33m.\\u001b[39mprefix \\u001b[33m=\\u001b[39m prefix\\n \\u001b[90m 5 | \\u001b[39m  }\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 6 | \\u001b[39m  get(key\\u001b[33m,\\u001b[39m \\u001b[36mdefault\\u001b[39m \\u001b[33m=\\u001b[39m \\u001b[36mnull\\u001b[39m){\\n \\u001b[90m   | \\u001b[39m           \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 7 | \\u001b[39m    \\u001b[36mreturn\\u001b[39m \\u001b[33mConfig\\u001b[39m\\u001b[33m.\\u001b[39mget(prefix \\u001b[33m+\\u001b[39m \\u001b[32m\\\"-\\\"\\u001b[39m \\u001b[33m+\\u001b[39mkey\\u001b[33m,\\u001b[39m\\u001b[36mdefault\\u001b[39m)\\n \\u001b[90m 8 | \\u001b[39m  }\\n \\u001b[90m 9 | \\u001b[39m  set(key\\u001b[33m,\\u001b[39m value){\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjM0LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})