webpackHotUpdate(0,{

/***/ 283:
/* unknown exports provided */
/* all exports used */
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: c:/dev/MOB1/KarmaJobsApp/src/index.js: Duplicate declaration \\\"browserHistory\\\"\\n\\n\\u001b[0m \\u001b[90m 34 | \\u001b[39m\\u001b[36mvar\\u001b[39m store \\u001b[33m=\\u001b[39m configureStore()\\n \\u001b[90m 35 | \\u001b[39m\\u001b[90m// Create an enhanced history that syncs navigation events with the store\\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 36 | \\u001b[39m\\u001b[36mconst\\u001b[39m browserHistory \\u001b[33m=\\u001b[39m useRouterHistory(createBrowserHistory)({\\n \\u001b[90m    | \\u001b[39m      \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 37 | \\u001b[39m    basename\\u001b[33m:\\u001b[39m window\\u001b[33m.\\u001b[39mlocation\\u001b[33m.\\u001b[39mpathname\\n \\u001b[90m 38 | \\u001b[39m})\\n \\u001b[90m 39 | \\u001b[39m\\u001b[36mconst\\u001b[39m history \\u001b[33m=\\u001b[39m syncHistoryWithStore(browserHistory \\u001b[33m,\\u001b[39m store)\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjgzLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})