webpackHotUpdate(0,{

/***/ 102:
/* unknown exports provided */
/* all exports used */
/*!********************************************!*\
  !*** ./src/reducers/configureStore.dev.js ***!
  \********************************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/reducers/configureStore.dev.js: Unexpected token, expected ; (21:48)\\n\\n\\u001b[0m \\u001b[90m 19 | \\u001b[39m)\\u001b[33m;\\u001b[39m\\n \\u001b[90m 20 | \\u001b[39m\\u001b[36mconst\\u001b[39m initialState \\u001b[33m=\\u001b[39m {}\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 21 | \\u001b[39m\\u001b[36mexport\\u001b[39m \\u001b[36mdefault\\u001b[39m configureStore \\u001b[33m=>\\u001b[39m (initialState) {\\n \\u001b[90m    | \\u001b[39m                                                \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 22 | \\u001b[39m  \\u001b[90m// Note: only Redux >= 3.1.0 supports passing enhancer as third argument.\\u001b[39m\\n \\u001b[90m 23 | \\u001b[39m  \\u001b[90m// See https://github.com/reactjs/redux/releases/tag/v3.1.0\\u001b[39m\\n \\u001b[90m 24 | \\u001b[39m  \\u001b[36mconst\\u001b[39m store \\u001b[33m=\\u001b[39m createStore(reducers\\u001b[33m,\\u001b[39m initialState\\u001b[33m,\\u001b[39m enhancer)\\u001b[33m;\\u001b[39m\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTAyLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})