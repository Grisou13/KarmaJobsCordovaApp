webpackHotUpdate(0,{

/***/ 280:
/* unknown exports provided */
/* all exports used */
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/index.js: Expected corresponding JSX closing tag for <App> (55:6)\\n\\n\\u001b[0m \\u001b[90m 53 | \\u001b[39m        \\u001b[33m<\\u001b[39m\\u001b[33mRoute\\u001b[39m path\\u001b[33m=\\u001b[39m\\u001b[32m\\\"jobs\\\"\\u001b[39m component\\u001b[33m=\\u001b[39m{\\u001b[33mUserIsAuthenticated\\u001b[39m(\\u001b[33mJobList\\u001b[39m)}\\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m 54 | \\u001b[39m        \\u001b[33m<\\u001b[39m\\u001b[33mRoute\\u001b[39m path\\u001b[33m=\\u001b[39m\\u001b[32m\\\"jobs/:id\\\"\\u001b[39m component\\u001b[33m=\\u001b[39m{\\u001b[33mUserIsAuthenticated\\u001b[39m(\\u001b[33mJob\\u001b[39m)}\\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 55 | \\u001b[39m      \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mRoute\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m    | \\u001b[39m      \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 56 | \\u001b[39m      \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mApp\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m 57 | \\u001b[39m  \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mProvider\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[33m,\\u001b[39m\\n \\u001b[90m 58 | \\u001b[39m  document\\u001b[33m.\\u001b[39mgetElementById(\\u001b[32m'mount'\\u001b[39m)\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjgwLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})