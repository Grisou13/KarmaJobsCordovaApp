webpackHotUpdate(0,{

/***/ 276:
/* unknown exports provided */
/* all exports used */
/*!**************************!*\
  !*** ./src/utils/api.js ***!
  \**************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n            value: true\n});\nexports.getApiUrlFromConfig = undefined;\n\nvar _axios = __webpack_require__(/*! axios */ 253);\n\nvar _axios2 = _interopRequireDefault(_axios);\n\nvar _config = __webpack_require__(/*! ./config */ 277);\n\nvar _config2 = _interopRequireDefault(_config);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar conf = new _config2.default(\"api\");\nvar getApiUrlFromConfig = exports.getApiUrlFromConfig = function getApiUrlFromConfig() {\n            return \"http://karmajobs.servehttp.com/api\";\n};\nvar api = _axios2.default.create({\n            baseURL: _config2.default.get(\"api_url\", getApiUrlFromConfig()),\n            timeout: _config2.default.get(\"api_timeout\", 100000),\n            contentType: \"application/json\",\n            headers: { 'Authorization': \"Bearer \" + _config2.default.get(\"access_token\") }\n});\nexports.default = api;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjc2LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy91dGlscy9hcGkuanM/OTNhZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXHJcbmltcG9ydCBjb25maWcgZnJvbSAnLi9jb25maWcnXHJcbmNvbnN0IGNvbmYgPSBuZXcgY29uZmlnKFwiYXBpXCIpXHJcbmV4cG9ydCBjb25zdCBnZXRBcGlVcmxGcm9tQ29uZmlnID0gKCkgPT4gKFwiaHR0cDovL2thcm1ham9icy5zZXJ2ZWh0dHAuY29tL2FwaVwiKVxyXG5jb25zdCBhcGkgPSBheGlvcy5jcmVhdGUoe1xyXG4gICAgICAgICAgICBiYXNlVVJMOiBjb25maWcuZ2V0KFwiYXBpX3VybFwiLCBnZXRBcGlVcmxGcm9tQ29uZmlnKCkpLFxyXG4gICAgICAgICAgICB0aW1lb3V0OiBjb25maWcuZ2V0KFwiYXBpX3RpbWVvdXRcIiwxMDAwMDApLFxyXG4gICAgICAgICAgICBjb250ZW50VHlwZTpcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgaGVhZGVyczogeydBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIrY29uZmlnLmdldChcImFjY2Vzc190b2tlblwiKX1cclxuICAgICAgICB9KTtcclxuZXhwb3J0IGRlZmF1bHQgYXBpO1xyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL3V0aWxzL2FwaS5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7OztBQUFBO0FBQ0E7Ozs7O0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQSIsInNvdXJjZVJvb3QiOiIifQ==");

/***/ })

})