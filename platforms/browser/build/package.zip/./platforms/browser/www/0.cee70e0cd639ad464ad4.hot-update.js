webpackHotUpdate(0,{

/***/ 695:
/* unknown exports provided */
/* all exports used */
/*!**********************************!*\
  !*** ./src/reducers/tracking.js ***!
  \**********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.defaultState = undefined;\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar _tracking = __webpack_require__(/*! ./../consts/tracking */ 694);\n\nvar defaultState = exports.defaultState = {\n  latitude: null,\n  longitude: null,\n  history: []\n};\n\nvar trackingReducer = function trackingReducer() {\n  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultState;\n  var action = arguments[1];\n\n  switch (action.type) {\n    case _tracking.UPDATE_POSITION:\n      return _extends({}, state, action.payload, { history: state.history.concat([action.payload]) });\n    case _tracking.RESET_POSITION:\n      return _extends({}, state, { latitude: defaultState.latitude, longitude: defaultState.longitude });\n    default:\n      return state;\n  }\n};\n\nexports.default = trackingReducer;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjk1LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9yZWR1Y2Vycy90cmFja2luZy5qcz9jYjRjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7VVBEQVRFX1BPU0lUSU9OLCBSRVNFVF9QT1NJVElPTn0gZnJvbSAnLi8uLi9jb25zdHMvdHJhY2tpbmcnXHJcbmV4cG9ydCBjb25zdCBkZWZhdWx0U3RhdGUgPSB7XHJcbiAgbGF0aXR1ZGU6bnVsbCxcclxuICBsb25naXR1ZGU6bnVsbCxcclxuICBoaXN0b3J5OiBbXVxyXG59XHJcblxyXG5jb25zdCB0cmFja2luZ1JlZHVjZXIgPSAoc3RhdGUgPSBkZWZhdWx0U3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gIHN3aXRjaChhY3Rpb24udHlwZSl7XHJcbiAgICBjYXNlIFVQREFURV9QT1NJVElPTjpcclxuICAgICAgcmV0dXJuIHsuLi5zdGF0ZSwgLi4uYWN0aW9uLnBheWxvYWQsIGhpc3Rvcnk6IHN0YXRlLmhpc3RvcnkuY29uY2F0KFthY3Rpb24ucGF5bG9hZF0pfVxyXG4gICAgY2FzZSBSRVNFVF9QT1NJVElPTjpcclxuICAgICAgcmV0dXJuIHsuLi5zdGF0ZSwgbGF0aXR1ZGU6IGRlZmF1bHRTdGF0ZS5sYXRpdHVkZSwgbG9uZ2l0dWRlOiBkZWZhdWx0U3RhdGUubG9uZ2l0dWRlfVxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gIH1cclxufVxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHRyYWNraW5nUmVkdWNlclxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL3JlZHVjZXJzL3RyYWNraW5nLmpzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUNBO0FBS0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7QUFDQTtBQUVBIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})