webpackHotUpdate(0,{

/***/ 235:
/* unknown exports provided */
/* all exports used */
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar _react = __webpack_require__(/*! react */ 2);\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ 233);\n\nvar _reactDom2 = _interopRequireDefault(_reactDom);\n\nvar _redux = __webpack_require__(/*! redux */ 42);\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ 132);\n\nvar _reactRouter = __webpack_require__(/*! react-router */ 134);\n\nvar _reactRouterRedux = __webpack_require__(/*! react-router-redux */ 133);\n\nvar _reduxAuthWrapper = __webpack_require__(/*! redux-auth-wrapper */ 616);\n\nvar _app = __webpack_require__(/*! ./containers/app */ 627);\n\nvar _app2 = _interopRequireDefault(_app);\n\nvar _history = __webpack_require__(/*! history */ 612);\n\nvar _reducers = __webpack_require__(/*! ./reducers */ 71);\n\nvar _reducers2 = _interopRequireDefault(_reducers);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\n// Add the reducer to your store on the `routing` key\nvar isClient = function isClient() {\n  return typeof window !== 'undefined' && window.document;\n};\n\nvar store = (0, _reducers2.default)();\n// Create an enhanced history that syncs navigation events with the store\nvar bHistory = (0, _history.createBrowserHistory)();\nconsole.log(bHistory);\nconsole.log(\"ASDSD\");\nvar history = (0, _reactRouterRedux.syncHistoryWithStore)(bHistory, store);\n// Redirects to /login by default\nvar UserIsAuthenticated = (0, _reduxAuthWrapper.UserAuthWrapper)({\n  authSelector: function authSelector(state) {\n    return state.user;\n  }, // how to get the user state\n  redirectAction: _reactRouterRedux.routerActions.replace, // the redux action to dispatch for redirect\n  wrapperDisplayName: 'UserIsAuthenticated' // a nice name for this auth check\n});\n\n_reactDom2.default.render(_react2.default.createElement(\n  _reactRedux.Provider,\n  { store: store },\n  _react2.default.createElement(\n    _reactRouter.Router,\n    { history: history },\n    _react2.default.createElement(\n      _reactRouter.Route,\n      { path: '/', component: _app2.default },\n      _react2.default.createElement(_reactRouter.Route, { path: 'foo', component: Foo }),\n      _react2.default.createElement(_reactRouter.Route, { path: 'bar', component: Bar })\n    )\n  )\n), document.getElementById('mount'));//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjM1LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9pbmRleC5qcz8xZmRmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSdcclxuaW1wb3J0IHsgY3JlYXRlU3RvcmUsIGNvbWJpbmVSZWR1Y2VycyB9IGZyb20gJ3JlZHV4J1xyXG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gJ3JlYWN0LXJlZHV4J1xyXG5pbXBvcnQgeyBSb3V0ZXIsIFJvdXRlLCBicm93c2VySGlzdG9yeSAgfSBmcm9tICdyZWFjdC1yb3V0ZXInXHJcbmltcG9ydCB7IHJvdXRlclJlZHVjZXIsIHN5bmNIaXN0b3J5V2l0aFN0b3JlLCByb3V0ZXJBY3Rpb25zLCByb3V0ZXJNaWRkbGV3YXJlIH0gZnJvbSAncmVhY3Qtcm91dGVyLXJlZHV4J1xyXG5pbXBvcnQgeyBVc2VyQXV0aFdyYXBwZXIgfSBmcm9tICdyZWR1eC1hdXRoLXdyYXBwZXInXHJcbmltcG9ydCBBcHAgZnJvbSAnLi9jb250YWluZXJzL2FwcCdcclxuaW1wb3J0IHsgY3JlYXRlQnJvd3Nlckhpc3RvcnkgfSBmcm9tICdoaXN0b3J5JztcclxuXHJcbmltcG9ydCBjb25maWd1cmVTdG9yZSBmcm9tICcuL3JlZHVjZXJzJ1xyXG5cclxuLy8gQWRkIHRoZSByZWR1Y2VyIHRvIHlvdXIgc3RvcmUgb24gdGhlIGByb3V0aW5nYCBrZXlcclxuY29uc3QgaXNDbGllbnQgPSAoKSA9PiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmRvY3VtZW50KTtcclxuXHJcbnZhciBzdG9yZSA9IGNvbmZpZ3VyZVN0b3JlKClcclxuLy8gQ3JlYXRlIGFuIGVuaGFuY2VkIGhpc3RvcnkgdGhhdCBzeW5jcyBuYXZpZ2F0aW9uIGV2ZW50cyB3aXRoIHRoZSBzdG9yZVxyXG5jb25zdCBiSGlzdG9yeSA9IGNyZWF0ZUJyb3dzZXJIaXN0b3J5KClcclxuY29uc29sZS5sb2coYkhpc3RvcnkpXHJcbmNvbnNvbGUubG9nKFwiQVNEU0RcIik7XHJcbmNvbnN0IGhpc3RvcnkgPSBzeW5jSGlzdG9yeVdpdGhTdG9yZShiSGlzdG9yeSAsIHN0b3JlKVxyXG4vLyBSZWRpcmVjdHMgdG8gL2xvZ2luIGJ5IGRlZmF1bHRcclxuY29uc3QgVXNlcklzQXV0aGVudGljYXRlZCA9IFVzZXJBdXRoV3JhcHBlcih7XHJcbiAgYXV0aFNlbGVjdG9yOiBzdGF0ZSA9PiBzdGF0ZS51c2VyLCAvLyBob3cgdG8gZ2V0IHRoZSB1c2VyIHN0YXRlXHJcbiAgcmVkaXJlY3RBY3Rpb246IHJvdXRlckFjdGlvbnMucmVwbGFjZSwgLy8gdGhlIHJlZHV4IGFjdGlvbiB0byBkaXNwYXRjaCBmb3IgcmVkaXJlY3RcclxuICB3cmFwcGVyRGlzcGxheU5hbWU6ICdVc2VySXNBdXRoZW50aWNhdGVkJyAvLyBhIG5pY2UgbmFtZSBmb3IgdGhpcyBhdXRoIGNoZWNrXHJcbn0pXHJcblxyXG5SZWFjdERPTS5yZW5kZXIoXHJcbiAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XHJcbiAgICB7IC8qIFRlbGwgdGhlIFJvdXRlciB0byB1c2Ugb3VyIGVuaGFuY2VkIGhpc3RvcnkgKi8gfVxyXG4gICAgPFJvdXRlciBoaXN0b3J5PXtoaXN0b3J5fT5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgY29tcG9uZW50PXtBcHB9PlxyXG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiZm9vXCIgY29tcG9uZW50PXtGb299Lz5cclxuICAgICAgICA8Um91dGUgcGF0aD1cImJhclwiIGNvbXBvbmVudD17QmFyfS8+XHJcbiAgICAgIDwvUm91dGU+XHJcbiAgICA8L1JvdXRlcj5cclxuICA8L1Byb3ZpZGVyPixcclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbW91bnQnKVxyXG4pXHJcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyBzcmMvaW5kZXguanMiXSwibWFwcGluZ3MiOiI7O0FBQUE7QUFDQTs7O0FBQUE7QUFDQTs7O0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBOzs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFIQTtBQUNBO0FBS0E7QUFDQTtBQUFBO0FBRUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUZBO0FBREE7QUFGQSIsInNvdXJjZVJvb3QiOiIifQ==");

/***/ }),

/***/ 627:
/* unknown exports provided */
/* all exports used */
/*!*******************************!*\
  !*** ./src/containers/app.js ***!
  \*******************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nif (false) {\n    module.exports = require('./App.prod');\n} else {\n    module.exports = __webpack_require__(/*! ./App.dev */ 628);\n}//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjI3LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9jb250YWluZXJzL2FwcC5qcz84YjdkIl0sInNvdXJjZXNDb250ZW50IjpbImlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XHJcbiAgICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vQXBwLnByb2QnKTtcclxufSBlbHNlIHtcclxuICAgIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9BcHAuZGV2Jyk7XHJcbn1cclxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHNyYy9jb250YWluZXJzL2FwcC5qcyJdLCJtYXBwaW5ncyI6Ijs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlUm9vdCI6IiJ9");

/***/ }),

/***/ 628:
/* unknown exports provided */
/* all exports used */
/*!***********************************!*\
  !*** ./src/containers/App.dev.js ***!
  \***********************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/containers/App.dev.js: Leading decorators must be attached to a class declaration (13:0)\\n\\n\\u001b[0m \\u001b[90m 11 | \\u001b[39m    }\\n \\u001b[90m 12 | \\u001b[39m})\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 13 | \\u001b[39m\\u001b[36mconst\\u001b[39m \\u001b[33mApp\\u001b[39m \\u001b[33m=\\u001b[39m ({uiKey\\u001b[33m,\\u001b[39m ui\\u001b[33m,\\u001b[39m updateUI\\u001b[33m,\\u001b[39m resetUI}) \\u001b[33m=>\\u001b[39m {\\n \\u001b[90m    | \\u001b[39m\\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 14 | \\u001b[39m    let cl \\u001b[33m=\\u001b[39m displayModeEnabled \\u001b[33m?\\u001b[39m \\u001b[32m\\\"glyphicon-remove\\\"\\u001b[39m \\u001b[33m:\\u001b[39m \\u001b[32m\\\"glyphicon-fullscreen\\\"\\u001b[39m\\n \\u001b[90m 15 | \\u001b[39m    \\u001b[36mreturn\\u001b[39m (\\n \\u001b[90m 16 | \\u001b[39m        \\u001b[33m<\\u001b[39m\\u001b[33mdiv\\u001b[39m className\\u001b[33m=\\u001b[39m\\u001b[32m\\\"app-container\\\"\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjI4LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})