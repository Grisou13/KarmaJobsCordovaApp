webpackHotUpdate(0,{

/***/ 59:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: C:/dev/MOB1/KarmaJobsApp/src/actions/user.js: Unexpected token, expected { (25:7)\\n\\n  23 |   }\\n  24 | }\\n> 25 | export logout = () => dispatch => {\\n     |        ^\\n  26 | \\n  27 |   dispatch({\\n  28 |     type: constants.USER_LOGGED_OUT\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNTkuanMiLCJzb3VyY2VzIjpbXSwibWFwcGluZ3MiOiIiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})