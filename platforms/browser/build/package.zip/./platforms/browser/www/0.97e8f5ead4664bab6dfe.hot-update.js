webpackHotUpdate(0,{

/***/ 687:
/* unknown exports provided */
/* all exports used */
/*!****************************!*\
  !*** ./src/actions/job.js ***!
  \****************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nexports.fetchJobs = exports.error = exports.fetching = exports.gotJobs = undefined;\n\nvar _api = __webpack_require__(/*! ../utils/api */ 289);\n\nvar _api2 = _interopRequireDefault(_api);\n\nvar _jobs = __webpack_require__(/*! ../consts/jobs */ 282);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\n/**\r\n * Created by Thomas.RICCI on 15.06.2017.\r\n */\n\nvar gotJobs = exports.gotJobs = function gotJobs(list) {\n    return {\n        type: _jobs.FETCHED_JOBS,\n        payload: list\n    };\n};\nvar fetching = exports.fetching = function fetching() {\n    return {\n        type: _jobs.FETCHING_JOBS\n    };\n};\nvar error = exports.error = function error(err) {\n    return {\n        type: _jobs.FETCH_JOBS_ERROR,\n        payload: err\n    };\n};\nvar fetchJobs = exports.fetchJobs = function fetchJobs() {\n    return function (dispatch) {\n        dispatch(fetching());\n        _api2.default.getInstance().getJobs().then(function (res) {\n            return dispatch(gotJobs(res.data));\n        }).catch(function (err) {\n            return dispatch(error(err));\n        });\n    };\n};//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjg3LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9hY3Rpb25zL2pvYi5qcz81OGI2Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDcmVhdGVkIGJ5IFRob21hcy5SSUNDSSBvbiAxNS4wNi4yMDE3LlxyXG4gKi9cclxuXHJcblxyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi91dGlscy9hcGlcIjtcclxuaW1wb3J0IHtGRVRDSF9KT0JTX0VSUk9SLCBGRVRDSEVEX0pPQlMsIEZFVENISU5HX0pPQlN9IGZyb20gXCIuLi9jb25zdHMvam9ic1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IGdvdEpvYnMgPSAobGlzdCkgPT4gKHtcclxuICAgIHR5cGU6IEZFVENIRURfSk9CUyxcclxuICAgIHBheWxvYWQ6IGxpc3RcclxufSlcclxuZXhwb3J0IGNvbnN0IGZldGNoaW5nID0gKCkgPT4gKHtcclxuICAgIHR5cGU6IEZFVENISU5HX0pPQlNcclxufSlcclxuZXhwb3J0IGNvbnN0IGVycm9yID0gKGVycikgPT4gKHtcclxuICAgIHR5cGU6IEZFVENIX0pPQlNfRVJST1IsXHJcbiAgICBwYXlsb2FkOiBlcnJcclxufSlcclxuZXhwb3J0IGNvbnN0IGZldGNoSm9icyA9ICgpID0+IGRpc3BhdGNoID0+IHtcclxuICAgIGRpc3BhdGNoKGZldGNoaW5nKCkpXHJcbiAgICBhcGkuZ2V0SW5zdGFuY2UoKS5nZXRKb2JzKClcclxuICAgICAgICAudGhlbihyZXMgPT4gZGlzcGF0Y2goZ290Sm9icyhyZXMuZGF0YSkpKVxyXG4gICAgICAgIC5jYXRjaChlcnIgPT4gZGlzcGF0Y2goZXJyb3IoZXJyKSkpXHJcbn1cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL2FjdGlvbnMvam9iLmpzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBS0E7QUFDQTs7O0FBQUE7QUFDQTs7O0FBUEE7Ozs7QUFRQTtBQUFBO0FBQ0E7QUFDQTtBQUZBO0FBQUE7QUFJQTtBQUFBO0FBQ0E7QUFEQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQ0E7QUFGQTtBQUFBO0FBSUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBTEEiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})