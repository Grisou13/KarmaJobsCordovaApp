webpackHotUpdate(0,{

/***/ 242:
/* unknown exports provided */
/* all exports used */
/*!***********************************!*\
  !*** ./src/containers/App.dev.js ***!
  \***********************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/containers/App.dev.js: Decorators are not officially supported yet in 6.x pending a proposal update.\\nHowever, if you need to use them you can install the legacy decorators transform with:\\n\\nnpm install babel-plugin-transform-decorators-legacy --save-dev\\n\\nand add the following line to your .babelrc file:\\n\\n{\\n  \\\"plugins\\\": [\\\"transform-decorators-legacy\\\"]\\n}\\n\\nThe repo url is: https://github.com/loganfsmyth/babel-plugin-transform-decorators-legacy.\\n    \\n\\n\\u001b[0m \\u001b[90m 11 | \\u001b[39m    }\\n \\u001b[90m 12 | \\u001b[39m})\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 13 | \\u001b[39m\\u001b[36mclass\\u001b[39m \\u001b[33mApp\\u001b[39m \\u001b[36mextends\\u001b[39m \\u001b[33mReact\\u001b[39m\\u001b[33m.\\u001b[39m\\u001b[33mComponent\\u001b[39m{\\n \\u001b[90m    | \\u001b[39m\\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 14 | \\u001b[39m    render(){\\n \\u001b[90m 15 | \\u001b[39m      \\u001b[36mreturn\\u001b[39m (\\n \\u001b[90m 16 | \\u001b[39m          \\u001b[33m<\\u001b[39m\\u001b[33mdiv\\u001b[39m className\\u001b[33m=\\u001b[39m\\u001b[32m\\\"app-container\\\"\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjQyLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})