webpackHotUpdate(0,{

/***/ 257:
/* unknown exports provided */
/* all exports used */
/*!***********************************!*\
  !*** ./src/containers/JobList.js ***!
  \***********************************/
/***/ (function(module, exports) {

"use strict";
eval("throw new Error(\"Module build failed: SyntaxError: C:/dev/MOB1/KarmaJobsApp/src/containers/JobList.js: Unexpected token (11:42)\\n\\n\\u001b[0m \\u001b[90m  9 | \\u001b[39m      \\u001b[36mreturn\\u001b[39m (\\n \\u001b[90m 10 | \\u001b[39m          \\u001b[33m<\\u001b[39m\\u001b[33mdiv\\u001b[39m className\\u001b[33m=\\u001b[39m\\u001b[32m\\\"app-container\\\"\\u001b[39m\\u001b[33m>\\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 11 | \\u001b[39m              {\\u001b[36mthis\\u001b[39m\\u001b[33m.\\u001b[39mprops\\u001b[33m.\\u001b[39mjobs\\u001b[33m.\\u001b[39mmap( j \\u001b[33m=>\\u001b[39m  )}\\n \\u001b[90m    | \\u001b[39m                                          \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 12 | \\u001b[39m          \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mdiv\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m 13 | \\u001b[39m      )\\n \\u001b[90m 14 | \\u001b[39m    }\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjU3LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})