webpackHotUpdate(0,{

/***/ 151:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/utils/config.js ***!
  \*****************************/
/***/ (function(module, exports) {

"use strict";
eval("throw new Error(\"Module build failed: SyntaxError: C:/dev/MOB1/KarmaJobsApp/src/utils/config.js: Unexpected token (22:4)\\n\\n\\u001b[0m \\u001b[90m 20 | \\u001b[39m          \\u001b[36mreturn\\u001b[39m \\u001b[33mConfig\\u001b[39m\\u001b[33m.\\u001b[39mset(key\\u001b[33m,\\u001b[39m d)\\n \\u001b[90m 21 | \\u001b[39m      }\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 22 | \\u001b[39m    \\u001b[36melse\\u001b[39m\\n \\u001b[90m    | \\u001b[39m    \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 23 | \\u001b[39m      \\u001b[36mreturn\\u001b[39m item\\n \\u001b[90m 24 | \\u001b[39m  }\\n \\u001b[90m 25 | \\u001b[39m  static set( key \\u001b[33m,\\u001b[39mvalue ){\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTUxLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})