webpackHotUpdate(0,{

/***/ 235:
/* unknown exports provided */
/* all exports used */
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/index.js: Unexpected token, expected , (13:49)\\n\\n\\u001b[0m \\u001b[90m 11 | \\u001b[39m\\u001b[90m// Add the reducer to your store on the `routing` key\\u001b[39m\\n \\u001b[90m 12 | \\u001b[39m\\u001b[36mconst\\u001b[39m isClient \\u001b[33m=\\u001b[39m () \\u001b[33m=>\\u001b[39m (\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 13 | \\u001b[39m\\t\\u001b[36mtypeof\\u001b[39m window \\u001b[33m!==\\u001b[39m \\u001b[32m'undefined'\\u001b[39m \\u001b[33m&&\\u001b[39m window\\u001b[33m.\\u001b[39mdocument\\u001b[33m;\\u001b[39m\\n \\u001b[90m    | \\u001b[39m\\t                                                \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 14 | \\u001b[39m)\\u001b[33m;\\u001b[39m\\n \\u001b[90m 15 | \\u001b[39m\\n \\u001b[90m 16 | \\u001b[39m\\u001b[36mvar\\u001b[39m store \\u001b[33m=\\u001b[39m configureStore()\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjM1LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})