webpackHotUpdate(0,{

/***/ 1022:
/* unknown exports provided */
/* all exports used */
/*!***********************************!*\
  !*** ./src/components/JobList.js ***!
  \***********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar _react = __webpack_require__(/*! react */ 1);\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _propTypes = __webpack_require__(/*! prop-types */ 4);\n\nvar _propTypes2 = _interopRequireDefault(_propTypes);\n\nvar _Job = __webpack_require__(/*! ./Job */ 404);\n\nvar _Job2 = _interopRequireDefault(_Job);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar JobList = function JobList(_ref) {\n    var jobs = _ref.jobs,\n        current_location = _ref.current_location;\n\n    return _react2.default.createElement(\n        \"div\",\n        { className: \"job-list\" },\n        jobs.map(function (j) {\n            return _react2.default.createElement(_Job2.default, _extends({ key: j.id }, j, { currentPosition: current_location }));\n        })\n    );\n};\n\nJobList.propTypes = {\n    jobs: _propTypes2.default.array,\n    current_location: _propTypes2.default.object\n};\n\nexports.default = JobList;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTAyMi5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy9zcmMvY29tcG9uZW50cy9Kb2JMaXN0LmpzPzE5ZmEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gXCJwcm9wLXR5cGVzXCI7XHJcblxyXG5pbXBvcnQgSm9iIGZyb20gXCIuL0pvYlwiO1xyXG5cclxuY29uc3QgSm9iTGlzdCA9ICh7am9icywgY3VycmVudF9sb2NhdGlvbn0pID0+IHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiam9iLWxpc3RcIj5cclxuICAgICAgICAgICAgICB7am9icy5tYXAoIGogPT4gPEpvYiBrZXk9e2ouaWR9IHsuLi5qfSBjdXJyZW50UG9zaXRpb249e2N1cnJlbnRfbG9jYXRpb259IC8+ICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgKVxyXG59XHJcblxyXG5Kb2JMaXN0LnByb3BUeXBlcyA9IHtcclxuICAgIGpvYnM6IFByb3BUeXBlcy5hcnJheSxcclxuICAgIGN1cnJlbnRfbG9jYXRpb246IFByb3BUeXBlcy5vYmplY3RcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSm9iTGlzdFxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL2NvbXBvbmVudHMvSm9iTGlzdC5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTtBQUNBOzs7QUFBQTtBQUNBOzs7QUFDQTtBQUNBOzs7OztBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBREE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFDQTtBQUlBIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})