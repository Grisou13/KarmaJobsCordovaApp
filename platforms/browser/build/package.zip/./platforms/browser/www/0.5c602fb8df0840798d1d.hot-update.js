webpackHotUpdate(0,{

/***/ 629:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.login = undefined;\nexports.logout = logout;\n\nvar _user = __webpack_require__(/*! ../consts/user */ 630);\n\nvar constants = _interopRequireWildcard(_user);\n\nfunction _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }\n\nvar login = exports.login = function login(data) {\n  return function (dispatch) {\n    dispatch({\n      type: constants.USER_LOGGING_IN\n    });\n    // Wait 2 seconds before \"logging in\"\n    setTimeout(function () {\n      dispatch({\n        type: constants.USER_LOGGED_IN,\n        payload: data\n      });\n    }, 2000);\n  };\n};\n\nfunction logout() {\n  return {\n    type: constants.USER_LOGGED_OUT\n  };\n}//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjI5LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9hY3Rpb25zL3VzZXIuanM/ZWU0YSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjb25zdGFudHMgZnJvbSAnLi4vY29uc3RzL3VzZXInXHJcblxyXG5leHBvcnQgY29uc3QgbG9naW4gPSBkYXRhID0+IGRpc3BhdGNoID0+IHtcclxuICBkaXNwYXRjaCh7XHJcbiAgICB0eXBlOiBjb25zdGFudHMuVVNFUl9MT0dHSU5HX0lOXHJcbiAgfSlcclxuICAvLyBXYWl0IDIgc2Vjb25kcyBiZWZvcmUgXCJsb2dnaW5nIGluXCJcclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogY29uc3RhbnRzLlVTRVJfTE9HR0VEX0lOLFxyXG4gICAgICBwYXlsb2FkOiBkYXRhXHJcbiAgICB9KVxyXG4gIH0sIDIwMDApXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBsb2dvdXQoKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGNvbnN0YW50cy5VU0VSX0xPR0dFRF9PVVRcclxuICB9XHJcbn1cclxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHNyYy9hY3Rpb25zL3VzZXIuanMiXSwibWFwcGluZ3MiOiI7Ozs7OztBQWVBO0FBQ0E7QUFoQkE7QUFDQTtBQURBO0FBQ0E7OztBQUNBO0FBQUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBWEE7QUFDQTtBQVlBO0FBQ0E7QUFDQTtBQURBO0FBR0EiLCJzb3VyY2VSb290IjoiIn0=");

/***/ }),

/***/ 630:
/* unknown exports provided */
/* all exports used */
/*!****************************!*\
  !*** ./src/consts/user.js ***!
  \****************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar USER_LOGGING_IN = exports.USER_LOGGING_IN = 'USER_LOGGING_IN';\nvar USER_LOGGED_IN = exports.USER_LOGGED_IN = 'USER_LOGGED_IN';\nvar USER_LOGGED_OUT = exports.USER_LOGGED_OUT = 'USER_LOGGED_OUT';//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjMwLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9jb25zdHMvdXNlci5qcz9kZTg2Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBVU0VSX0xPR0dJTkdfSU4gPSAnVVNFUl9MT0dHSU5HX0lOJ1xyXG5leHBvcnQgY29uc3QgVVNFUl9MT0dHRURfSU4gPSAnVVNFUl9MT0dHRURfSU4nXHJcbmV4cG9ydCBjb25zdCBVU0VSX0xPR0dFRF9PVVQgPSAnVVNFUl9MT0dHRURfT1VUJ1xyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL2NvbnN0cy91c2VyLmpzIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBO0FBQ0E7QUFDQSIsInNvdXJjZVJvb3QiOiIifQ==");

/***/ })

})