webpackHotUpdate(0,{

/***/ 695:
/* unknown exports provided */
/* all exports used */
/*!**********************************!*\
  !*** ./src/reducers/tracking.js ***!
  \**********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.defaultState = undefined;\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar _tracking = __webpack_require__(/*! ./../consts/tracking */ 694);\n\nvar defaultState = exports.defaultState = {\n  latitude: null,\n  longitude: null,\n  history: []\n};\n\nvar trackingReducer = function trackingReducer() {\n  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultState;\n  var action = arguments[1];\n\n  switch (action.type) {\n    case _tracking.UPDATE_POSITION:\n      return _extends({}, state, { latitude: action.payload.latitude, longitude: action.payload.longitude, history: state.history.concat([action.payload]) });\n    case _tracking.RESET_POSITION:\n      return _extends({}, state, { latitude: defaultState.latitude, longitude: defaultState.longitude });\n    default:\n      return state;\n  }\n};\n\nexports.default = trackingReducer;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjk1LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9yZWR1Y2Vycy90cmFja2luZy5qcz9jYjRjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7VVBEQVRFX1BPU0lUSU9OLCBSRVNFVF9QT1NJVElPTn0gZnJvbSAnLi8uLi9jb25zdHMvdHJhY2tpbmcnXHJcbmV4cG9ydCBjb25zdCBkZWZhdWx0U3RhdGUgPSB7XHJcbiAgbGF0aXR1ZGU6bnVsbCxcclxuICBsb25naXR1ZGU6bnVsbCxcclxuICBoaXN0b3J5OiBbXVxyXG59XHJcblxyXG5jb25zdCB0cmFja2luZ1JlZHVjZXIgPSAoc3RhdGUgPSBkZWZhdWx0U3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gIHN3aXRjaChhY3Rpb24udHlwZSl7XHJcbiAgICBjYXNlIFVQREFURV9QT1NJVElPTjpcclxuICAgICAgcmV0dXJuIHsuLi5zdGF0ZSwgbGF0aXR1ZGU6IGFjdGlvbi5wYXlsb2FkLmxhdGl0dWRlLCBsb25naXR1ZGU6IGFjdGlvbi5wYXlsb2FkLmxvbmdpdHVkZSwgaGlzdG9yeTogc3RhdGUuaGlzdG9yeS5jb25jYXQoW2FjdGlvbi5wYXlsb2FkXSl9XHJcbiAgICBjYXNlIFJFU0VUX1BPU0lUSU9OOlxyXG4gICAgICByZXR1cm4gey4uLnN0YXRlLCBsYXRpdHVkZTogZGVmYXVsdFN0YXRlLmxhdGl0dWRlLCBsb25naXR1ZGU6IGRlZmF1bHRTdGF0ZS5sb25naXR1ZGV9XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gc3RhdGU7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgdHJhY2tpbmdSZWR1Y2VyXHJcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyBzcmMvcmVkdWNlcnMvdHJhY2tpbmcuanMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBQ0E7QUFLQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTtBQUNBO0FBRUEiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})