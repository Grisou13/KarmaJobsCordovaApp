webpackHotUpdate(0,{

/***/ 60:
/* unknown exports provided */
/* all exports used */
/*!**************************!*\
  !*** ./src/utils/api.js ***!
  \**************************/
/***/ (function(module, exports) {

"use strict";
eval("throw new Error(\"Module build failed: SyntaxError: C:/dev/MOB1/KarmaJobsApp/src/utils/api.js: `ApiConfig` has already been exported. Exported identifiers must be unique. (78:13)\\n\\n  76 | }\\n  77 | export default Api;\\n> 78 | export const ApiConfig = conf\\n     |              ^\\n  79 | \\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjAuanMiLCJzb3VyY2VzIjpbXSwibWFwcGluZ3MiOiIiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})