webpackHotUpdate(0,{

/***/ 688:
/* unknown exports provided */
/* all exports used */
/*!********************************!*\
  !*** ./src/middlewares/job.js ***!
  \********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _user = __webpack_require__(/*! ../consts/user */ 150);\n\nvar _job = __webpack_require__(/*! ../actions/job */ 687);\n\n/**\r\n * Created by Thomas.RICCI on 15.06.2017.\r\n */\n\nvar LogginMiddleware = function LogginMiddleware(store) {\n    return function (next) {\n        return function (action) {\n            var res = next(action);\n            if (action.type === _user.USER_LOGGED_IN) store.dispatch((0, _job.fetchJobs)());\n            return res;\n        };\n    };\n};\n\nexports.default = LogginMiddleware;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjg4LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9taWRkbGV3YXJlcy9qb2IuanM/MzY3YiJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQ3JlYXRlZCBieSBUaG9tYXMuUklDQ0kgb24gMTUuMDYuMjAxNy5cclxuICovXHJcblxyXG5cclxuaW1wb3J0IHtVU0VSX0xPR0dFRF9JTn0gZnJvbSBcIi4uL2NvbnN0cy91c2VyXCI7XHJcbmltcG9ydCB7ZmV0Y2hKb2JzfSBmcm9tIFwiLi4vYWN0aW9ucy9qb2JcIjtcclxuY29uc3QgTG9nZ2luTWlkZGxld2FyZSA9IHN0b3JlID0+IG5leHQgPT4gYWN0aW9uID0+IHtcclxuICAgIGxldCByZXMgPSBuZXh0KGFjdGlvbilcclxuICAgIGlmKGFjdGlvbi50eXBlID09PSBVU0VSX0xPR0dFRF9JTilcclxuICAgICAgICBzdG9yZS5kaXNwYXRjaChmZXRjaEpvYnMoKSlcclxuICAgIHJldHVybiByZXNcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9nZ2luTWlkZGxld2FyZVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyBzcmMvbWlkZGxld2FyZXMvam9iLmpzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQTtBQUNBO0FBQUE7QUFDQTtBQVBBOzs7O0FBT0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFMQTtBQUFBO0FBQ0E7QUFNQSIsInNvdXJjZVJvb3QiOiIifQ==");

/***/ })

})