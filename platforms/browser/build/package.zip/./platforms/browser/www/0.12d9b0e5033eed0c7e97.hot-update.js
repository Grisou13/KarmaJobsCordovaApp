webpackHotUpdate(0,{

/***/ 10:
false,

/***/ 139:
false,

/***/ 140:
false,

/***/ 141:
false,

/***/ 142:
false,

/***/ 143:
false,

/***/ 144:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/***/ (function(module, exports) {

"use strict";
eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/actions/user.js: Unexpected token, expected { (23:7)\\n\\n\\u001b[0m \\u001b[90m 21 | \\u001b[39m  }\\n \\u001b[90m 22 | \\u001b[39m}\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 23 | \\u001b[39m\\u001b[36mexport\\u001b[39m signup \\u001b[33m=\\u001b[39m profile \\u001b[33m=>\\u001b[39m dispatch \\u001b[33m=>\\u001b[39m {\\n \\u001b[90m    | \\u001b[39m       \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 24 | \\u001b[39m  setTimeout(() \\u001b[33m=>\\u001b[39m {\\n \\u001b[90m 25 | \\u001b[39m    dispatch({\\n \\u001b[90m 26 | \\u001b[39m      type\\u001b[33m:\\u001b[39m constants\\u001b[33m.\\u001b[39m\\u001b[33mUSER_LOGGED_IN\\u001b[39m\\u001b[33m,\\u001b[39m\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTQ0LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ }),

/***/ 253:
false,

/***/ 254:
false,

/***/ 255:
false,

/***/ 256:
false,

/***/ 257:
false,

/***/ 258:
false,

/***/ 259:
false,

/***/ 260:
false,

/***/ 261:
false,

/***/ 262:
false,

/***/ 263:
false,

/***/ 264:
false,

/***/ 265:
false,

/***/ 266:
false,

/***/ 267:
false,

/***/ 268:
false,

/***/ 269:
false,

/***/ 270:
false,

/***/ 271:
false,

/***/ 276:
false,

/***/ 277:
false,

/***/ 364:
false,

/***/ 365:
false,

/***/ 366:
false,

/***/ 384:
false,

/***/ 79:
false

})