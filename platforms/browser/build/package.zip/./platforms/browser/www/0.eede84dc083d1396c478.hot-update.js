webpackHotUpdate(0,{

/***/ 277:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/utils/config.js ***!
  \*****************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/utils/config.js: Unexpected token (6:14)\\n\\n\\u001b[0m \\u001b[90m 4 | \\u001b[39m    \\u001b[36mthis\\u001b[39m\\u001b[33m.\\u001b[39mprefix \\u001b[33m=\\u001b[39m prefix\\n \\u001b[90m 5 | \\u001b[39m  }\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 6 | \\u001b[39m  get \\u001b[33m=\\u001b[39m (key\\u001b[33m,\\u001b[39m \\u001b[36mdefault\\u001b[39m \\u001b[33m=\\u001b[39m \\u001b[36mnull\\u001b[39m) \\u001b[33m=>\\u001b[39m {\\n \\u001b[90m   | \\u001b[39m              \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 7 | \\u001b[39m    \\u001b[36mreturn\\u001b[39m \\u001b[33mConfig\\u001b[39m\\u001b[33m.\\u001b[39mget(prefix \\u001b[33m+\\u001b[39m \\u001b[32m\\\"-\\\"\\u001b[39m \\u001b[33m+\\u001b[39mkey\\u001b[33m,\\u001b[39m\\u001b[36mdefault\\u001b[39m)\\n \\u001b[90m 8 | \\u001b[39m  }\\n \\u001b[90m 9 | \\u001b[39m  set \\u001b[33m=\\u001b[39m (key\\u001b[33m,\\u001b[39m value) \\u001b[33m=>\\u001b[39m {\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjc3LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})