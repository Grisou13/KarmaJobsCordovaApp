webpackHotUpdate(0,{

/***/ 285:
/* unknown exports provided */
/* all exports used */
/*!**************************!*\
  !*** ./src/utils/api.js ***!
  \**************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nexports.login = exports.getApiUrlFromConfig = undefined;\n\nvar _axios = __webpack_require__(/*! axios */ 262);\n\nvar _axios2 = _interopRequireDefault(_axios);\n\nvar _config = __webpack_require__(/*! ./config */ 286);\n\nvar _config2 = _interopRequireDefault(_config);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar conf = new _config2.default(\"api\");\nvar getApiUrlFromConfig = exports.getApiUrlFromConfig = function getApiUrlFromConfig() {\n    return \"http://karmajobs.servehttp.com/api\";\n};\nvar api = _axios2.default.create({\n    baseURL: conf.get(\"url\", getApiUrlFromConfig()),\n    timeout: conf.get(\"timeout\", 100000),\n    contentType: \"application/json\",\n    headers: { 'Authorization': \"Bearer \" + conf.get(\"access_token\") }\n});\n\nvar login = exports.login = function login(data) {\n    return api.post(\"/auth\", data).then(function (res) {\n        return res.data.token;\n    }).then(function (token) {\n        conf.set(\"access_token\", token);\n        return api.get(\"/me\");\n    });\n};\n\nexports.default = api;//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjg1LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy91dGlscy9hcGkuanM/OTNhZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXHJcbmltcG9ydCBjb25maWcgZnJvbSAnLi9jb25maWcnXHJcbmNvbnN0IGNvbmYgPSBuZXcgY29uZmlnKFwiYXBpXCIpXHJcbmV4cG9ydCBjb25zdCBnZXRBcGlVcmxGcm9tQ29uZmlnID0gKCkgPT4gKFwiaHR0cDovL2thcm1ham9icy5zZXJ2ZWh0dHAuY29tL2FwaVwiKVxyXG5jb25zdCBhcGkgPSBheGlvcy5jcmVhdGUoe1xyXG4gICAgICAgICAgICBiYXNlVVJMOiBjb25mLmdldChcInVybFwiLCBnZXRBcGlVcmxGcm9tQ29uZmlnKCkpLFxyXG4gICAgICAgICAgICB0aW1lb3V0OiBjb25mLmdldChcInRpbWVvdXRcIiwxMDAwMDApLFxyXG4gICAgICAgICAgICBjb250ZW50VHlwZTpcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgaGVhZGVyczogeydBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIrY29uZi5nZXQoXCJhY2Nlc3NfdG9rZW5cIil9XHJcbiAgICAgICAgfSk7XHJcblxyXG5leHBvcnQgY29uc3QgbG9naW4gPSAoZGF0YSkgPT4ge1xyXG4gICAgcmV0dXJuIGFwaS5wb3N0KFwiL2F1dGhcIixkYXRhKS50aGVuKChyZXMpPT5yZXMuZGF0YS50b2tlbikudGhlbih0b2tlbiA9PiB7XHJcbiAgICAgICAgY29uZi5zZXQoXCJhY2Nlc3NfdG9rZW5cIiwgdG9rZW4pXHJcbiAgICAgICAgcmV0dXJuIGFwaS5nZXQoXCIvbWVcIilcclxuXHJcbiAgICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhcGk7XHJcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyBzcmMvdXRpbHMvYXBpLmpzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTs7O0FBQUE7QUFDQTs7Ozs7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQUNBO0FBTUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})