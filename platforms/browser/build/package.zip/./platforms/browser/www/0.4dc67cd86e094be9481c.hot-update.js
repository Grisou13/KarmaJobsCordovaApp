webpackHotUpdate(0,{

/***/ 137:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.login = undefined;\nexports.logout = logout;\n\nvar _user = __webpack_require__(/*! ../consts/user */ 246);\n\nvar constants = _interopRequireWildcard(_user);\n\nvar _api = __webpack_require__(/*! ../utils/api */ 633);\n\nvar _api2 = _interopRequireDefault(_api);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }\n\nvar login = exports.login = function login(data) {\n  return function (dispatch) {\n    dispatch({\n      type: constants.USER_LOGGING_IN\n    });\n\n    // Wait 2 seconds before \"logging in\"\n    // store email + token in localstorage\n    setTimeout(function () {\n      dispatch({\n        type: constants.USER_LOGGED_IN,\n        payload: data\n      });\n    }, 2000);\n  };\n};\n\nfunction logout() {\n  return {\n    type: constants.USER_LOGGED_OUT\n  };\n}//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTM3LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9hY3Rpb25zL3VzZXIuanM/ZWU0YSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjb25zdGFudHMgZnJvbSAnLi4vY29uc3RzL3VzZXInXHJcbmltcG9ydCBhcGkgZnJvbSAnLi4vdXRpbHMvYXBpJ1xyXG5leHBvcnQgY29uc3QgbG9naW4gPSBkYXRhID0+IGRpc3BhdGNoID0+IHtcclxuICBkaXNwYXRjaCh7XHJcbiAgICB0eXBlOiBjb25zdGFudHMuVVNFUl9MT0dHSU5HX0lOXHJcbiAgfSlcclxuXHJcbiAgLy8gV2FpdCAyIHNlY29uZHMgYmVmb3JlIFwibG9nZ2luZyBpblwiXHJcbiAgLy8gc3RvcmUgZW1haWwgKyB0b2tlbiBpbiBsb2NhbHN0b3JhZ2VcclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogY29uc3RhbnRzLlVTRVJfTE9HR0VEX0lOLFxyXG4gICAgICBwYXlsb2FkOiBkYXRhXHJcbiAgICB9KVxyXG4gIH0sIDIwMDApXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBsb2dvdXQoKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGNvbnN0YW50cy5VU0VSX0xPR0dFRF9PVVRcclxuICB9XHJcbn1cclxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHNyYy9hY3Rpb25zL3VzZXIuanMiXSwibWFwcGluZ3MiOiI7Ozs7OztBQWlCQTtBQUNBO0FBbEJBO0FBQ0E7QUFEQTtBQUNBO0FBQUE7QUFDQTs7Ozs7OztBQUFBO0FBQUE7QUFDQTtBQUNBO0FBREE7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQWJBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFEQTtBQUdBIiwic291cmNlUm9vdCI6IiJ9");

/***/ }),

/***/ 633:
/* unknown exports provided */
/* all exports used */
/*!**************************!*\
  !*** ./src/utils/api.js ***!
  \**************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/utils/api.js: Unexpected token (3:33)\\n\\n\\u001b[0m \\u001b[90m 1 | \\u001b[39m\\u001b[36mimport\\u001b[39m axios from \\u001b[32m'axios'\\u001b[39m\\n \\u001b[90m 2 | \\u001b[39m\\u001b[36mimport\\u001b[39m config from \\u001b[32m'./config'\\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 3 | \\u001b[39m\\u001b[36mexport\\u001b[39m \\u001b[36mconst\\u001b[39m getApiUrlFromConfig () \\u001b[33m=>\\u001b[39m (\\u001b[32m\\\"http://karmajobs.servehttp.com/api\\\"\\u001b[39m)\\n \\u001b[90m   | \\u001b[39m                                 \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 4 | \\u001b[39m\\u001b[36mconst\\u001b[39m api \\u001b[33m=\\u001b[39m axios\\u001b[33m.\\u001b[39mcreate({\\n \\u001b[90m 5 | \\u001b[39m            baseURL\\u001b[33m:\\u001b[39m config\\u001b[33m.\\u001b[39mget(\\u001b[32m\\\"api_url\\\"\\u001b[39m\\u001b[33m,\\u001b[39m getApiUrlFromConfig())\\u001b[33m,\\u001b[39m\\n \\u001b[90m 6 | \\u001b[39m            timeout\\u001b[33m:\\u001b[39m config\\u001b[33m.\\u001b[39mget(\\u001b[32m\\\"api_timeout\\\"\\u001b[39m\\u001b[33m,\\u001b[39m\\u001b[35m100000\\u001b[39m)\\u001b[33m,\\u001b[39m\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjMzLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})