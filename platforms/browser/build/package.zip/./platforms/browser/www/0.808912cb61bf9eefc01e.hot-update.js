webpackHotUpdate(0,{

/***/ 1001:
/* unknown exports provided */
/* all exports used */
/*!********************************!*\
  !*** ./src/containers/Jobs.js ***!
  \********************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/KarmaJobsApp/src/containers/Jobs.js: Unterminated regular expression (20:27)\\n\\n\\u001b[0m \\u001b[90m 18 | \\u001b[39m        \\u001b[36mreturn\\u001b[39m (\\n \\u001b[90m 19 | \\u001b[39m            \\u001b[33m<\\u001b[39m\\u001b[33mdiv\\u001b[39m\\u001b[33m>\\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 20 | \\u001b[39m                \\u001b[33m<\\u001b[39m\\u001b[33mMap\\u001b[39m jobs\\u001b[33m=\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m    | \\u001b[39m                           \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 21 | \\u001b[39m                \\u001b[33m<\\u001b[39m\\u001b[33mJobList\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m 22 | \\u001b[39m            \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mdiv\\u001b[39m\\u001b[33m>\\u001b[39m\\n \\u001b[90m 23 | \\u001b[39m        )\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTAwMS5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==");

/***/ })

})