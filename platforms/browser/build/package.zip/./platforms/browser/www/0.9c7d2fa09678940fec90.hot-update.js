webpackHotUpdate(0,{

/***/ 693:
/* unknown exports provided */
/* all exports used */
/*!*********************************!*\
  !*** ./src/actions/tracking.js ***!
  \*********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.resetPosition = exports.updatePosition = undefined;\n\nvar _tracking = __webpack_require__(/*! ./../consts/tracking */ 694);\n\nvar updatePosition = exports.updatePosition = function updatePosition(pos) {\n  return {\n    type: _tracking.UPDATE_POSITION,\n    payload: pos\n  };\n};\n\nvar resetPosition = exports.resetPosition = function resetPosition() {\n  return {\n    type: _tracking.RESET_POSITION,\n    payload: null\n  };\n};//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjkzLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9hY3Rpb25zL3RyYWNraW5nLmpzPzMxNDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtVUERBVEVfUE9TSVRJT04sIFJFU0VUX1BPU0lUSU9OfSBmcm9tICcuLy4uL2NvbnN0cy90cmFja2luZydcclxuXHJcblxyXG5leHBvcnQgY29uc3QgdXBkYXRlUG9zaXRpb24gPSAocG9zKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IFVQREFURV9QT1NJVElPTixcclxuICAgIHBheWxvYWQ6IHBvc1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHJlc2V0UG9zaXRpb24gPSAoKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IFJFU0VUX1BPU0lUSU9OLFxyXG4gICAgcGF5bG9hZDogbnVsbFxyXG4gIH1cclxufVxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL2FjdGlvbnMvdHJhY2tpbmcuanMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUEiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})