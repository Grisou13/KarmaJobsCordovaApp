webpackHotUpdate(0,{

/***/ 373:
/* unknown exports provided */
/* all exports used */
/*!*********************************!*\
  !*** ./src/actions/tracking.js ***!
  \*********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.error = exports.resetPosition = exports.updatePosition = undefined;\n\nvar _tracking = __webpack_require__(/*! ./../consts/tracking */ 238);\n\nvar updatePosition = exports.updatePosition = function updatePosition(pos) {\n  return {\n    type: _tracking.UPDATE_POSITION,\n    payload: pos\n  };\n};\n\nvar resetPosition = exports.resetPosition = function resetPosition() {\n  return {\n    type: _tracking.RESET_POSITION,\n    payload: null\n  };\n};\n\nvar error = exports.error = function error(_error) {\n  return {\n    type: _tracking.TRACKING_ERROR,\n    error: _error\n  };\n};//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMzczLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9hY3Rpb25zL3RyYWNraW5nLmpzPzMxNDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtVUERBVEVfUE9TSVRJT04sIFJFU0VUX1BPU0lUSU9OLCBUUkFDS0lOR19FUlJPUn0gZnJvbSAnLi8uLi9jb25zdHMvdHJhY2tpbmcnXHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IHVwZGF0ZVBvc2l0aW9uID0gKHBvcykgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBVUERBVEVfUE9TSVRJT04sXHJcbiAgICBwYXlsb2FkOiBwb3NcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCByZXNldFBvc2l0aW9uID0gKCkgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBSRVNFVF9QT1NJVElPTixcclxuICAgIHBheWxvYWQ6IG51bGxcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBlcnJvciA9IChlcnJvcikgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBUUkFDS0lOR19FUlJPUixcclxuICAgIGVycm9yXHJcbiAgfVxyXG59XHJcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyBzcmMvYWN0aW9ucy90cmFja2luZy5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})