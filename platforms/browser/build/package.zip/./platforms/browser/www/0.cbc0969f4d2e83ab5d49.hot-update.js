webpackHotUpdate(0,{

/***/ 629:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.login = undefined;\nexports.logout = logout;\n\nvar _user = __webpack_require__(/*! ../consts/user */ 630);\n\nvar constants = _interopRequireWildcard(_user);\n\nfunction _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }\n\nvar login = exports.login = function login(data) {\n  return function (dispatch) {\n    dispatch({\n      type: constants.USER_LOGGING_IN\n    });\n\n    // Wait 2 seconds before \"logging in\"\n    // //store email + token in localstorage\n    setTimeout(function () {\n      dispatch({\n        type: constants.USER_LOGGED_IN,\n        payload: data\n      });\n    }, 2000);\n  };\n};\n\nfunction logout() {\n  return {\n    type: constants.USER_LOGGED_OUT\n  };\n}//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjI5LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL3NyYy9hY3Rpb25zL3VzZXIuanM/ZWU0YSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjb25zdGFudHMgZnJvbSAnLi4vY29uc3RzL3VzZXInXHJcblxyXG5leHBvcnQgY29uc3QgbG9naW4gPSBkYXRhID0+IGRpc3BhdGNoID0+IHtcclxuICBkaXNwYXRjaCh7XHJcbiAgICB0eXBlOiBjb25zdGFudHMuVVNFUl9MT0dHSU5HX0lOXHJcbiAgfSlcclxuXHJcbiAgLy8gV2FpdCAyIHNlY29uZHMgYmVmb3JlIFwibG9nZ2luZyBpblwiXHJcbiAgLy8gLy9zdG9yZSBlbWFpbCArIHRva2VuIGluIGxvY2Fsc3RvcmFnZVxyXG4gIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBjb25zdGFudHMuVVNFUl9MT0dHRURfSU4sXHJcbiAgICAgIHBheWxvYWQ6IGRhdGFcclxuICAgIH0pXHJcbiAgfSwgMjAwMClcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGxvZ291dCgpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogY29uc3RhbnRzLlVTRVJfTE9HR0VEX09VVFxyXG4gIH1cclxufVxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gc3JjL2FjdGlvbnMvdXNlci5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBaUJBO0FBQ0E7QUFsQkE7QUFDQTtBQURBO0FBQ0E7OztBQUNBO0FBQUE7QUFDQTtBQUNBO0FBREE7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQWJBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFEQTtBQUdBIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})