webpackHotUpdate(0,{

/***/ 11:
false,

/***/ 145:
false,

/***/ 146:
false,

/***/ 147:
false,

/***/ 148:
false,

/***/ 149:
false,

/***/ 262:
false,

/***/ 263:
false,

/***/ 264:
false,

/***/ 265:
false,

/***/ 266:
false,

/***/ 267:
false,

/***/ 268:
false,

/***/ 269:
false,

/***/ 270:
false,

/***/ 271:
false,

/***/ 272:
false,

/***/ 273:
false,

/***/ 274:
false,

/***/ 275:
false,

/***/ 276:
false,

/***/ 277:
false,

/***/ 278:
false,

/***/ 279:
false,

/***/ 280:
false,

/***/ 285:
false,

/***/ 286:
false,

/***/ 373:
false,

/***/ 374:
false,

/***/ 375:
false,

/***/ 391:
false,

/***/ 81:
false,

/***/ 82:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/KarmaJobsApp/src/actions/user.js: Unexpected token, expected { (17:7)\\n\\n\\u001b[0m \\u001b[90m 15 | \\u001b[39m  }\\u001b[33m,\\u001b[39m \\u001b[35m2000\\u001b[39m)\\n \\u001b[90m 16 | \\u001b[39m}\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 17 | \\u001b[39m\\u001b[36mexport\\u001b[39m loggedIn \\u001b[33m=\\u001b[39m (user) \\u001b[33m=>\\u001b[39m {\\n \\u001b[90m    | \\u001b[39m       \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 18 | \\u001b[39m  \\u001b[36mreturn\\u001b[39m {\\n \\u001b[90m 19 | \\u001b[39m      type\\u001b[33m:\\u001b[39m constants\\u001b[33m.\\u001b[39m\\u001b[33mUSER_LOGGED_IN\\u001b[39m\\u001b[33m,\\u001b[39m\\n \\u001b[90m 20 | \\u001b[39m      payload\\u001b[33m:\\u001b[39m user\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiODIuanMiLCJzb3VyY2VzIjpbXSwibWFwcGluZ3MiOiIiLCJzb3VyY2VSb290IjoiIn0=");

/***/ })

})