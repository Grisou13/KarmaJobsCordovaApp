webpackHotUpdate(0,{

/***/ 632:
/* unknown exports provided */
/* all exports used */
/*!*********************************!*\
  !*** ./src/containers/Login.js ***!
  \*********************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/containers/Login.js: Unexpected token (11:10)\\n\\n\\u001b[0m \\u001b[90m  9 | \\u001b[39m    \\u001b[36msuper\\u001b[39m(props)\\n \\u001b[90m 10 | \\u001b[39m  }\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 11 | \\u001b[39m  onClick \\u001b[33m=\\u001b[39m (e) \\u001b[33m=>\\u001b[39m {\\n \\u001b[90m    | \\u001b[39m          \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 12 | \\u001b[39m    e\\u001b[33m.\\u001b[39mpreventDefault()\\n \\u001b[90m 13 | \\u001b[39m    \\u001b[36mthis\\u001b[39m\\u001b[33m.\\u001b[39mprops\\u001b[33m.\\u001b[39mlogin({\\n \\u001b[90m 14 | \\u001b[39m      email\\u001b[33m:\\u001b[39m \\u001b[36mthis\\u001b[39m\\u001b[33m.\\u001b[39mrefs\\u001b[33m.\\u001b[39mname\\u001b[33m.\\u001b[39mvalue\\u001b[33m,\\u001b[39m\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNjMyLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})