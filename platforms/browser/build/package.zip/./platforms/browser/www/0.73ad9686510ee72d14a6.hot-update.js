webpackHotUpdate(0,{

/***/ 265:
/* unknown exports provided */
/* all exports used */
/*!******************************************!*\
  !*** ./src/containers/SettingsEditor.js ***!
  \******************************************/
/***/ (function(module, exports) {

"use strict";
eval("throw new Error(\"Module build failed: SyntaxError: C:/dev/MOB1/KarmaJobsApp/src/containers/SettingsEditor.js: missing super() call in constructor\\n\\n  17 | @connect(null, mapDispatchToProps)\\n  18 | class SettingsEditor extends React.Component {\\n> 19 |     constructor(props){\\n     |     ^\\n  20 | \\n  21 |     }\\n  22 |     state = {\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjY1LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})