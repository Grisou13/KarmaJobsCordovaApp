webpackHotUpdate(0,{

/***/ 277:
/* unknown exports provided */
/* all exports used */
/*!*****************************!*\
  !*** ./src/utils/config.js ***!
  \*****************************/
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: SyntaxError: c:/dev/MOB1/UberJob-Cordova/src/utils/config.js: Unexpected token (11:19)\\n\\n\\u001b[0m \\u001b[90m  9 | \\u001b[39m  \\u001b[90m// remove = (key) => Config.remove(this.prefix+key)\\u001b[39m\\n \\u001b[90m 10 | \\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 11 | \\u001b[39m  static get( key\\u001b[33m,\\u001b[39m \\u001b[36mdefault\\u001b[39m \\u001b[33m=\\u001b[39m \\u001b[36mnull\\u001b[39m ){\\n \\u001b[90m    | \\u001b[39m                   \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 12 | \\u001b[39m    let item \\u001b[33m=\\u001b[39m window\\u001b[33m.\\u001b[39mlocalStorage\\u001b[33m.\\u001b[39mgetItem(key)\\u001b[33m;\\u001b[39m\\n \\u001b[90m 13 | \\u001b[39m    \\u001b[36mif\\u001b[39m(\\u001b[36mtypeof\\u001b[39m item \\u001b[33m==\\u001b[39m \\u001b[32m\\\"undefined\\\"\\u001b[39m)\\n \\u001b[90m 14 | \\u001b[39m      \\u001b[36mif\\u001b[39m(\\u001b[36mtypeof\\u001b[39m \\u001b[36mdefault\\u001b[39m \\u001b[33m==\\u001b[39m \\u001b[32m\\\"function\\\"\\u001b[39m)\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjc3LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})