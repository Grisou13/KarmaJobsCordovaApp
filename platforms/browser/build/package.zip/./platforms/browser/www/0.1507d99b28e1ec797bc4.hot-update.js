webpackHotUpdate(0,{

/***/ 258:
/* unknown exports provided */
/* all exports used */
/*!*********************************!*\
  !*** ./src/containers/Login.js ***!
  \*********************************/
/***/ (function(module, exports) {

"use strict";
eval("throw new Error(\"Module build failed: SyntaxError: C:/dev/MOB1/KarmaJobsApp/src/containers/Login.js: Unexpected token, expected : (56:4)\\n\\n\\u001b[0m \\u001b[90m 54 | \\u001b[39m    \\u001b[36mconst\\u001b[39m isAuthenticated \\u001b[33m=\\u001b[39m state\\u001b[33m.\\u001b[39muser\\u001b[33m.\\u001b[39mname \\u001b[33m||\\u001b[39m \\u001b[36mfalse\\u001b[39m\\n \\u001b[90m 55 | \\u001b[39m    \\u001b[36mconst\\u001b[39m redirect \\u001b[33m=\\u001b[39m ownProps\\u001b[33m.\\u001b[39mlocation\\u001b[33m.\\u001b[39mquery \\u001b[33m?\\u001b[39m ownProps\\u001b[33m.\\u001b[39mlocation\\u001b[33m.\\u001b[39mquery\\u001b[33m.\\u001b[39mreplace \\u001b[33m||\\u001b[39m \\u001b[32m'/'\\u001b[39m\\n\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 56 | \\u001b[39m    \\u001b[36mreturn\\u001b[39m {\\n \\u001b[90m    | \\u001b[39m    \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\n \\u001b[90m 57 | \\u001b[39m        isAuthenticated\\u001b[33m,\\u001b[39m\\n \\u001b[90m 58 | \\u001b[39m        redirect\\n \\u001b[90m 59 | \\u001b[39m    }\\u001b[0m\\n\");//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMjU4LmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9");

/***/ })

})